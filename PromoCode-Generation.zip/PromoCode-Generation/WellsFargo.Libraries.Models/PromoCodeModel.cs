﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

namespace WellsFargo.Libraries.Models
{
    public class PromoCodeModel
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }
       
        [BsonElement("CampaignName")]
        public string CampaignName { get; set; }
       
        [BsonElement("NoOfPromoCodes")]
        public int NoOfPromoCodes { get; set; }
       
        [BsonElement("PromocodeCost")]
        public int PromocodeCost { get; set; }

        [BsonElement("StartDate")]
        public DateTime StartDate { get; set; }

        [BsonElement("EndDate")]
        public DateTime EndDate { get; set; }

        [BsonElement("Prefix")]
        public string Prefix { get; set; }

        [BsonElement("PromocodeGenerated")]
        public string PromocodeGenerated { get; set; }
        //public List<string> PromocodeGenerated { get; set; }
        //public Array PromocodeGenerated { get; set; }

        [BsonElement("Remarks")]
        public string Remarks { get; set; }

        [BsonElement("CampaignCreatedDate")]
        public DateTime CampaignCreatedDate { get; set; }

        [BsonElement("CreatedUserName")]
        public string CreatedUserName { get; set; }

        [BsonElement("CampaignStatus")]
        public string CampaignStatus { get; set; }

        [BsonElement("CancellaionResaon")]
        public string CancellaionResaon { get; set; }

        [BsonElement("CancelledDate")]
        public DateTime CancelledDate { get; set; }

        [BsonElement("CancelledUser")]
        public string CancelledUser { get; set; }

        [BsonElement("PortalPercentage")]
        public int PortalPercentage { get; set; }

        [BsonElement("FranschisePercentage")]
        public int FranschisePercentage { get; set; }

        [BsonElement("ChefPercentage")]
        public int ChefPercentage { get; set; }
    }
}
