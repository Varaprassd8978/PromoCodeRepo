﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WellsFargo.Libraries.Models
{
    public class PromoCodes
    {
        public Array RandomCodes { get; set; }
    }
}
