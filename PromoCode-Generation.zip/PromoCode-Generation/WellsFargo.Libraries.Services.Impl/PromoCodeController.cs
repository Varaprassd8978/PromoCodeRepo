﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WellsFargo.Libraries.Domian.Interfaces;
using WellsFargo.Libraries.Models;
using WellsFargo.Libraries.Services.Interfaces;

namespace WellsFargo.Libraries.Services.Impl
{
    [Route("api/[controller]")]
    [ApiController]
    public class PromoCodeController : ControllerBase, IPromoCodeController
    {

        private IPromoCodeDoaminServices promoCodeService = default;

        public PromoCodeController(IPromoCodeDoaminServices promoCodeService)
        {

            if (promoCodeService == default(IPromoCodeDoaminServices))
                throw new ArgumentNullException(nameof(promoCodeService));

            this.promoCodeService = promoCodeService;
        }


        [HttpPost]
        [Route("createnewcampaign")]
        public IActionResult CreateNewCampaign([FromBody] PromoCodeModel newPromoCodeModel)
        {
            //PromoCodeModel newPromoCodeModel = new PromoCodeModel();
            var result = this.promoCodeService.AddNewCampaign(newPromoCodeModel);
            return Ok(result);
        }

        [HttpGet]
        [Route("search/{searchString}")]
        public async Task<IActionResult> GetPromoCodeByCampaign(string searchString)
        {
            var result = await this.promoCodeService.GetPromoCodeByCampaign(searchString);

            return Ok(result);
        }

        [HttpGet]
        [Route("searchcampain/{campaignName}")]
        public async Task<IActionResult> SearchCampaign(string campaignName)
        {
            var result = await this.promoCodeService.SearchCampaign(campaignName);

            return Ok(result);
        }

        [HttpPut]
        [Route("updatecampagain")]
        public IActionResult UpdateCampaign([FromBody] PromoCodeModel updatePromoCodeModel)
        {
            var result = this.promoCodeService.UpdateCampaign(updatePromoCodeModel);

            return Ok(result);
        }

        [HttpGet]
        [Route("")]
        public IActionResult ViewAllCampaigns()
        {
            var viewAllCampaigns = default(IEnumerable<PromoCodeModel>);
            var result = default(IActionResult);

            viewAllCampaigns = this.promoCodeService.viewCampagin();

            result = Ok(viewAllCampaigns);

            return result;
        }
    }
}
